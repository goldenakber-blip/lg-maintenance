<?php
/**
 * نقاء الخليج - وظائف القالب
 * لتغيير رقم الهاتف: اذهب إلى المظهر > تخصيص > إعدادات الشركة
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/* ─── 1. دعم القالب الأساسي ─── */
function naqaa_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'html5', array( 'style', 'script' ) );
}
add_action( 'after_setup_theme', 'naqaa_setup' );

/* ─── 2. تحميل الخطوط والأنماط ─── */
function naqaa_enqueue_assets() {
    wp_enqueue_style(
        'cairo-font',
        'https://fonts.googleapis.com/css2?family=Cairo:wght@400;700;900&display=swap',
        array(),
        null
    );
    wp_enqueue_style(
        'naqaa-style',
        get_stylesheet_uri(),
        array(),
        '1.0.0'
    );
}
add_action( 'wp_enqueue_scripts', 'naqaa_enqueue_assets' );

/* ─── 3. WordPress Customizer — إعدادات الشركة ─── */
function naqaa_customize_register( $wp_customize ) {

    /* === قسم: إعدادات الشركة === */
    $wp_customize->add_section( 'naqaa_company_settings', array(
        'title'       => 'إعدادات الشركة',
        'description' => 'قم بتغيير رقم الهاتف والواتساب والسعر من هنا',
        'priority'    => 30,
    ) );

    /* — رقم الهاتف للاتصال — */
    $wp_customize->add_setting( 'naqaa_phone', array(
        'default'           => '0536871812',
        'sanitize_callback' => 'sanitize_text_field',
        'transport'         => 'postMessage',
    ) );
    $wp_customize->add_control( 'naqaa_phone', array(
        'label'       => 'رقم الهاتف (للاتصال)',
        'description' => 'يظهر في زر الاتصال وزر احجز موعدك',
        'section'     => 'naqaa_company_settings',
        'type'        => 'text',
    ) );

    /* — رقم واتساب — */
    $wp_customize->add_setting( 'naqaa_whatsapp', array(
        'default'           => '201149049682',
        'sanitize_callback' => 'sanitize_text_field',
        'transport'         => 'postMessage',
    ) );
    $wp_customize->add_control( 'naqaa_whatsapp', array(
        'label'       => 'رقم واتساب (مع كود الدولة، بدون +)',
        'description' => 'مثال: 201149049682 أو 966536871812',
        'section'     => 'naqaa_company_settings',
        'type'        => 'text',
    ) );

    /* — اسم الشركة — */
    $wp_customize->add_setting( 'naqaa_company_name', array(
        'default'           => 'نقاء الخليج',
        'sanitize_callback' => 'sanitize_text_field',
        'transport'         => 'postMessage',
    ) );
    $wp_customize->add_control( 'naqaa_company_name', array(
        'label'   => 'اسم الشركة',
        'section' => 'naqaa_company_settings',
        'type'    => 'text',
    ) );

    /* — السعر — */
    $wp_customize->add_setting( 'naqaa_price', array(
        'default'           => '135',
        'sanitize_callback' => 'sanitize_text_field',
        'transport'         => 'postMessage',
    ) );
    $wp_customize->add_control( 'naqaa_price', array(
        'label'   => 'السعر',
        'section' => 'naqaa_company_settings',
        'type'    => 'text',
    ) );
}
add_action( 'customize_register', 'naqaa_customize_register' );

/* ─── 4. دوال مساعدة لجلب القيم ─── */
function naqaa_get( $key, $default = '' ) {
    return esc_attr( get_theme_mod( $key, $default ) );
}
