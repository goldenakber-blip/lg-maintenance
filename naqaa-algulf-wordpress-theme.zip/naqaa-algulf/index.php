<?php
/**
 * القالب الرئيسي — نقاء الخليج
 * لتغيير الرقم: المظهر > تخصيص > إعدادات الشركة
 */
if ( ! defined( 'ABSPATH' ) ) exit;

$phone        = naqaa_get( 'naqaa_phone',        '0536871812' );
$whatsapp     = naqaa_get( 'naqaa_whatsapp',     '201149049682' );
$company_name = naqaa_get( 'naqaa_company_name', 'نقاء الخليج' );
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?> dir="rtl">
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo esc_html( $company_name ); ?> - خدمات التنظيف</title>
<?php wp_head(); ?>
<style>
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  html { direction: rtl; }
  body {
    font-family: 'Cairo', sans-serif;
    background: linear-gradient(to bottom, #f1f5f9, #eff6ff);
    min-height: 100dvh;
    display: flex;
    justify-content: center;
    overflow-x: hidden;
  }

  .page-wrap {
    width: 100%;
    max-width: 430px;
    background: #fff;
    box-shadow: 0 20px 60px rgba(0,0,0,.15);
    min-height: 100dvh;
    display: flex;
    flex-direction: column;
    position: relative;
    padding-bottom: 96px;
  }

  /* ── Floating Buttons ── */
  .floating-btns {
    position: fixed;
    left: 16px;
    bottom: 40px;
    display: flex;
    flex-direction: column;
    gap: 16px;
    z-index: 999;
    align-items: flex-start;
  }
  .float-btn {
    position: relative;
    width: 62px;
    height: 62px;
    text-decoration: none;
    display: block;
  }
  .float-btn .icon {
    width: 62px;
    height: 62px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: transform .2s;
    position: relative;
    z-index: 1;
  }
  .float-btn:hover .icon { transform: scale(1.15); }
  .float-btn:active .icon { transform: scale(.92); }
  .float-btn.wa .icon  { background: #25D366; box-shadow: 0 6px 24px rgba(37,211,102,.6); }
  .float-btn.tel .icon { background: #2563eb; box-shadow: 0 6px 24px rgba(37,99,235,.6); }
  .float-btn .icon svg { width: 30px; height: 30px; fill: #fff; }
  /* حلقة نابضة */
  .float-btn .ring {
    position: absolute;
    inset: 0;
    border-radius: 50%;
    animation: ripple 1.6s ease-out infinite;
    z-index: 0;
  }
  .float-btn.wa  .ring { background: #25D366; }
  .float-btn.tel .ring { background: #2563eb; animation-delay: .5s; }
  @keyframes ripple {
    0%   { transform: scale(1);   opacity: .5; }
    100% { transform: scale(1.6); opacity: 0; }
  }
  /* لابل عند hover */
  .float-btn .label {
    position: absolute;
    right: 70px;
    top: 50%;
    transform: translateY(-50%);
    font-size: 12px;
    font-weight: 900;
    color: #fff;
    border-radius: 10px;
    padding: 6px 12px;
    white-space: nowrap;
    pointer-events: none;
    opacity: 0;
    transition: opacity .2s;
  }
  .float-btn:hover .label { opacity: 1; }
  .float-btn.wa  .label { background: #25D366; }
  .float-btn.tel .label { background: #2563eb; }
  /* نبض الزر نفسه */
  .float-btn.wa  .icon { animation: btnpulse-wa  1.6s ease-in-out infinite; }
  .float-btn.tel .icon { animation: btnpulse-tel 1.6s ease-in-out infinite .5s; }
  @keyframes btnpulse-wa  { 0%,100%{transform:scale(1)} 50%{transform:scale(1.08)} }
  @keyframes btnpulse-tel { 0%,100%{transform:scale(1)} 50%{transform:scale(1.08)} }
  .float-btn:hover .icon { animation: none; transform: scale(1.15); }

  /* ── Header ── */
  .hero {
    background: #1e3a8a;
    color: #fff;
    padding: 44px 24px 40px;
    border-radius: 0 0 2.5rem 2.5rem;
    text-align: center;
    position: relative;
    overflow: hidden;
    box-shadow: 0 12px 40px rgba(30,58,138,.25);
  }
  .hero::before {
    content:''; position:absolute; right:-40px; top:-40px;
    width:210px; height:210px; background:#3b82f6;
    border-radius:50%; filter:blur(60px); opacity:.45;
  }
  .hero::after {
    content:''; position:absolute; left:-40px; bottom:-40px;
    width:210px; height:210px; background:#22d3ee;
    border-radius:50%; filter:blur(60px); opacity:.28;
  }
  .hero-inner { position:relative; z-index:2; }
  .hero-icon {
    background: rgba(255,255,255,.12);
    border: 1px solid rgba(255,255,255,.2);
    border-radius: 1.25rem;
    display: inline-flex; padding: 14px;
    margin-bottom: 18px;
    backdrop-filter: blur(8px);
  }
  .hero-icon svg { width: 44px; height: 44px; fill: #fde047; }
  .hero h1 { font-size: 2.5rem; font-weight: 900; letter-spacing:-.5px; margin-bottom:14px; }
  .hero .tagline {
    background: rgba(255,255,255,.12);
    border: 1px solid rgba(255,255,255,.18);
    border-radius: 999px;
    padding: 9px 28px;
    font-weight: 900;
    font-size: 1.2rem;
    color: #e0f2fe;
    display: inline-block;
    letter-spacing: .04em;
  }

  /* ── Services ── */
  .services { padding: 28px 20px 0; }
  .services-title {
    text-align: center;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    font-size: 1.2rem;
    font-weight: 900;
    color: #1e3a8a;
    margin-bottom: 20px;
  }
  .services-title svg { width:20px; height:20px; fill:#eab308; }
  .services-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
  .svc {
    border: 2px solid;
    border-radius: 1.25rem;
    padding: 14px 16px;
    display: flex; align-items: center; gap: 10px;
    transition: transform .2s;
  }
  .svc:hover { transform: translateY(-4px); }
  .svc svg { width:22px; height:22px; flex-shrink:0; stroke-width:3; }
  .svc span { font-size: 1rem; font-weight: 900; }
  .svc1 { background:#eff6ff; border-color:#bfdbfe; color:#1e40af; } .svc1 svg { stroke:#3b82f6; }
  .svc2 { background:#f0f9ff; border-color:#bae6fd; color:#075985; } .svc2 svg { stroke:#0284c7; }
  .svc3 { background:#fffbeb; border-color:#fde68a; color:#92400e; } .svc3 svg { stroke:#d97706; }
  .svc4 { background:#f0fdf4; border-color:#bbf7d0; color:#14532d; } .svc4 svg { stroke:#16a34a; }
  .svc5 { background:#f5f3ff; border-color:#ddd6fe; color:#4c1d95; } .svc5 svg { stroke:#7c3aed; }
  .svc6 { background:#f0fdfa; border-color:#99f6e4; color:#134e4a; } .svc6 svg { stroke:#0d9488; }

  /* ── Trust ── */
  .trust { padding: 24px 20px 0; }
  .trust-grid { display: grid; grid-template-columns: repeat(3,1fr); gap: 12px; }
  .trust-item {
    background: #f8fafc; border:1px solid #e2e8f0;
    border-radius:1.25rem; padding:14px 8px;
    text-align:center; display:flex; flex-direction:column; align-items:center; gap:8px;
  }
  .trust-icon { background:#dbeafe; border-radius:.75rem; padding:10px; display:inline-flex; }
  .trust-icon svg { width:24px; height:24px; stroke:#1d4ed8; fill:none; stroke-width:2.5; }
  .trust-label { font-size:.82rem; font-weight:900; color:#1e293b; }

  /* ── CTA ── */
  .cta-section { padding: 32px 20px 0; }
  .cta-btn {
    display:flex; align-items:center; justify-content:center; gap:12px;
    width:100%; background:#2563eb; color:#fff; text-decoration:none;
    font-size:1.4rem; font-weight:900;
    padding:20px 24px; border-radius:1.25rem;
    box-shadow: 0 10px 40px -10px rgba(37,99,235,.8);
    transition:all .2s;
  }
  .cta-btn:hover { background:#1d4ed8; transform:scale(1.02); }
  .cta-btn:active { transform:scale(.97); }
  .cta-btn svg { width:26px; height:26px; stroke:#fff; fill:none; stroke-width:2.5; }
  .cta-note {
    text-align:center; font-size:.8rem; font-weight:700; color:#94a3b8;
    background:#f8fafc; border:1px solid #e2e8f0;
    border-radius:999px; padding:8px 24px;
    width:max-content; margin:14px auto 0;
  }

  /* ── Footer ── */
  .page-footer { margin:24px 0 12px; text-align:center; }
  .footer-credit {
    display:inline-flex; align-items:center; gap:6px;
    font-size:.74rem; color:#cbd5e1; text-decoration:none; transition:color .2s;
  }
  .footer-credit:hover { color:#25D366; }
  .footer-credit svg { width:13px; height:13px; fill:#cbd5e1; transition:fill .2s; }
  .footer-credit:hover svg { fill:#25D366; }
</style>
</head>
<body>

<!-- Floating Buttons -->
<div class="floating-btns">
  <a href="https://wa.me/<?php echo esc_attr( $whatsapp ); ?>" target="_blank" rel="noopener noreferrer" class="float-btn wa">
    <span class="ring"></span>
    <span class="label">تواصل واتساب</span>
    <span class="icon">
      <svg viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
    </span>
  </a>
  <a href="tel:<?php echo esc_attr( $phone ); ?>" class="float-btn tel">
    <span class="ring"></span>
    <span class="label">اتصل الآن</span>
    <span class="icon">
      <svg viewBox="0 0 24 24"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg>
    </span>
  </a>
</div>

<div class="page-wrap">

  <!-- Header -->
  <header class="hero">
    <div class="hero-inner">
      <div class="hero-icon">
        <svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>
      </div>
      <h1><?php echo esc_html( $company_name ); ?></h1>
      <p class="tagline">أي وقت.. نظافة</p>
    </div>
  </header>

  <!-- Services -->
  <div class="services">
    <div class="services-title">
      <svg viewBox="0 0 24 24"><path d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
      خدماتنا الشاملة
      <svg viewBox="0 0 24 24"><path d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
    </div>
    <div class="services-grid">
      <div class="svc svc1">
        <svg viewBox="0 0 24 24"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
        <span>تنظيف شامل</span>
      </div>
      <div class="svc svc2">
        <svg viewBox="0 0 24 24"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
        <span>تنظيف مكيفات</span>
      </div>
      <div class="svc svc3">
        <svg viewBox="0 0 24 24"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
        <span>تنظيف مجالس</span>
      </div>
      <div class="svc svc4">
        <svg viewBox="0 0 24 24"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
        <span>تنظيف شقق</span>
      </div>
      <div class="svc svc5">
        <svg viewBox="0 0 24 24"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
        <span>تنظيف فلل</span>
      </div>
      <div class="svc svc6">
        <svg viewBox="0 0 24 24"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
        <span>تنظيف خزانات</span>
      </div>
    </div>
  </div>

  <!-- Trust -->
  <div class="trust">
    <div class="trust-grid">
      <div class="trust-item">
        <span class="trust-icon"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg></span>
        <span class="trust-label">خدمة سريعة</span>
      </div>
      <div class="trust-item">
        <span class="trust-icon"><svg viewBox="0 0 24 24"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg></span>
        <span class="trust-label">ضمان الجودة</span>
      </div>
      <div class="trust-item">
        <span class="trust-icon"><svg viewBox="0 0 24 24"><path d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/></svg></span>
        <span class="trust-label">فريق محترف</span>
      </div>
    </div>
  </div>

  <!-- CTA -->
  <div class="cta-section">
    <a href="tel:<?php echo esc_attr( $phone ); ?>" class="cta-btn">
      <svg viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81 19.79 19.79 0 01.07 1.18 2 2 0 012 0h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L6.09 7.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 14.92z"/></svg>
      احجز موعدك الآن
    </a>
    <p class="cta-note">نصلك في أسرع وقت داخل مناطق الخدمة</p>
  </div>

  <!-- Footer -->
  <footer class="page-footer">
    <a href="https://wa.me/201149049682" target="_blank" rel="noopener noreferrer" class="footer-credit">
      <svg viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
      تصميم بواسطة محمد علي
    </a>
  </footer>

</div>
<?php wp_footer(); ?>
</body>
</html>
